package com.jk.sirra;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class registerActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnregister;
    EditText edtname;
    EditText edtphone;
    EditText edtemail;
    EditText edtpassword;
    TextView txtdob;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnregister =findViewById(R.id.btnregister);
        edtname = findViewById(R.id.edtname);
        edtphone =findViewById(R.id.edtphone);
        edtemail =findViewById(R.id.edtemail);
        edtpassword =findViewById(R.id.edtPassword);
        txtdob =findViewById(R.id.txtdob);
        txtdob.setOnClickListener(this);


        btnregister.setOnClickListener(this);

    }
    @Override
    public void onClick(View v )
    {
        if (v.getId() == btnregister.getId())
        {
            String data = edtname.getText().toString() + "\n" + edtphone.getText().toString() + "\n" + edtemail.getText().toString() + "\n" + edtpassword.getText().toString() +"\n" +txtdob.getText().toString();
            Toast.makeText(this, data, Toast.LENGTH_LONG).show();
        }
        else if (v.getId() == txtdob.getId())
        {
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, datePickerListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

        }

        }
        DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day_of_month)
            {
               String date  =String.valueOf(month+1)  +"/" + String.valueOf(day_of_month) +"/" +String.valueOf(year);
               txtdob.setText(date);
            }
        };

    }

