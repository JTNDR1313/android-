  var currentBalanceInput = document.getElementById('currentbalance');
  var amountInput = document.getElementById('amount');
  var finalBalanceInput = document.getElementById('leftbalance');
  var labelTransferMessage = document.getElementById('moneyTransferMessage');
  var labelAccNumber = document.getElementById('lblmessage');
  var otherAccNumber = document.getElementById('tonew');

var btn = document.getElementById('calculate');

  otherAccNumber.style.display = "none";
  var balance = 3500;
  setCurrentBalance();

  function setCurrentBalance() {

  currentBalanceInput.value = balance ;
  }

var z = localStorage.getItem("email")
$("span#nam").append(z);


   function toacc(){
        var x = document.getElementById("toaccount").value;
        if(x == "Other"){
          currentbalance.value = 1000;
         otherAccNumber.style.display = "block";
      }else {
             otherAccNumber.style.display = "none";
               }

}
function fromacc(){
  var x = document.getElementById("fromaccount").value;
  if(x == "SavingAccount"){
    currentbalance.value = 1000;

}else if (x == 'CheckingAccount'){
       currentbalance.value = 1500;
     } else{
       currentBalanceInput.value =3500;
     }
}


btn.addEventListener('click',onCalculate);

function onCalculate() {
  var ai = amountInput.value;
    balance-=ai;

      finalBalanceInput.value = balance;
      currentBalanceInput.value = balance;

if (currentBalanceInput.value <=0){
  alert("sorry...please add amount to your account");
     }
        }
