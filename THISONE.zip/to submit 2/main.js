  var currentBalanceInput = document.getElementById('currentbalance');
  var amountInput = document.getElementById('amount');
  var finalBalanceInput = document.getElementById('leftbalance');
  var labelTransferMessage = document.getElementById('moneyTransferMessage');

  var otherAccNumber = document.getElementById('tonew');
  var creditbalanceInput = document.getElementById('Totalcreditbalance');
  var creditbalanceleft = document.getElementById('creditleft');
  var btn = document.getElementById('calculate');

  otherAccNumber.style.display = "none";

  var balance = 0;
  var checkingAmount = 0;
  var savingAmount = 0;
  var creditAmount = 0;
  setCurrentBalance();

  function setupAccountBalances(){
    checkingAmount = 1500;
    savingAmount = 1000;
    creditAmount = 1000;
    fromacc();
  }

  function setCurrentBalance() {
    currentBalanceInput.value = checkingAmount+savingAmount+creditAmount;
  }

  function toacc(){
    var x = document.getElementById("toaccount").value;
    if(x == "Other"){
      otherAccNumber.style.display = "block";
    } else {
      otherAccNumber.style.display = "none";
    }
  }

  function fromacc(){
    var x = document.getElementById("fromaccount").value;
    if(x == "SavingAccount"){
      currentbalance.value = savingAmount;
    } else if (x == 'CheckingAccount'){
      currentbalance.value = checkingAmount;
    } else if (x == 'CreditAccount'){
      currentbalance.value = creditAmount;
    }else{
       setCurrentBalance.value =checkingAmount+savingAmount+creditAmount ;
    }
  }

  btn.addEventListener('click',onCalculate);

  function onCalculate() {
    var withdrawlAmount = amountInput.value;
    checkingAmount -= withdrawlAmount;
    if (checkingAmount < 0) {
      savingAmount += checkingAmount;
      checkingAmount = 0;
    }
    if (savingAmount < 0) {
      creditAmount += savingAmount;
      savingAmount = 0;
    }
    if (creditAmount < 0) {
      alert("sorry...please add amount to your account");
    }

    setCurrentBalance();

  finalBalanceInput.value = checkingAmount+savingAmount+creditAmount;
  }
