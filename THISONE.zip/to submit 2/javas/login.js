

function getinfo(){
var e = "jtndr" ;
var p = "jtndr" ;

var Username = document.getElementById("username").value;
var Password = document.getElementById("password").value;

  if (Username== e && Password== p){
  window.location ="menu.html";
return true;
}
else if (Username=="kang" && Password=="kang") {
  window.location ="menu.html";
  return false;

}
  else{
    alert("sorry...please check your email and password");
  }
}


function newp(){
  window.location ="login.html";

  var email = document.getElementById("nemail").value;
  var Npassword = document.getElementById("newp").value;
  var Cpassword = document.getElementById("newcp").value;

  $("input#btnsub").click(function(){
    e = email
    p = Cpassword
  })
}


function getadmin(){
var ae = "user" ;
var ap = "user" ;

var Username = document.getElementById("username").value;
var Password = document.getElementById("password").value;

  if (Username== ae && Password== ap){
  window.location ="table.html";
return true;
}
  else{
    alert("sorry...please check your email and password");
  }
}
